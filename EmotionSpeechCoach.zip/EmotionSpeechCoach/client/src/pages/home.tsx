import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mic, BarChart2, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">AI Speech Trainer</h1>
        <p className="text-muted-foreground text-lg">
          Improve your public speaking skills with AI-powered emotion analysis and feedback
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-3 rounded-full bg-primary/10">
                <Mic className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-semibold">Record Your Speech</h2>
              <p className="text-muted-foreground">
                Record or upload your speech for instant emotion analysis
              </p>
              <Link href="/record">
                <Button className="mt-2">
                  Start Recording
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-3 rounded-full bg-primary/10">
                <BarChart2 className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-semibold">View Reports</h2>
              <p className="text-muted-foreground">
                Access detailed analysis and feedback from your previous speeches
              </p>
              <Link href="/reports">
                <Button className="mt-2">
                  View Reports
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
