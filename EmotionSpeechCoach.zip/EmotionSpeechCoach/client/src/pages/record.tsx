import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import AudioRecorder from "@/components/audio-recorder";
import { apiRequest } from "@/lib/queryClient";
import type { InsertReport } from "@shared/schema";

const MAX_DURATION = 300; // 5 minutes maximum
const MAX_FILE_SIZE = 45 * 1024 * 1024; // 45MB limit

export default function Record() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [audioUrl, setAudioUrl] = useState<string>();
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeMutation = useMutation({
    mutationFn: async (audioBlob: Blob) => {
      if (audioBlob.size > MAX_FILE_SIZE) {
        throw new Error("Audio file is too large. Please record a shorter speech or use a lower quality setting.");
      }

      // Convert blob to base64 using FileReader
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          resolve(base64String.split(',')[1]); // Remove the data URL prefix
        };
        reader.readAsDataURL(audioBlob);
      });

      const response = await apiRequest("POST", "/api/analyze", { 
        audio: base64 
      });
      return response.json();
    }
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: InsertReport) => {
      const response = await apiRequest("POST", "/api/reports", data);
      return response.json();
    },
    onSuccess: (data) => {
      navigate(`/reports/${data.id}`);
    }
  });

  const handleRecordingComplete = (audioBlob: Blob) => {
    if (audioBlob.size > MAX_FILE_SIZE) {
      toast({
        title: "Error",
        description: "Recording is too large. Please keep your speech under 5 minutes.",
        variant: "destructive"
      });
      return;
    }

    const url = URL.createObjectURL(audioBlob);
    setAudioUrl(url);

    // Get audio duration using a promise
    const audio = new Audio(url);
    audio.addEventListener('loadedmetadata', () => {
      const duration = Math.round(audio.duration);
      console.log("Detected audio duration:", duration);
      setAudioDuration(duration);

      // Only show warning for very long recordings
      if (duration > MAX_DURATION) {
        toast({
          title: "Warning",
          description: "Recording exceeds 5 minutes. Analysis may take longer.",
          variant: "destructive"
        });
      }
    });
  };

  const handleAnalyze = async () => {
    if (!audioUrl) {
      toast({
        title: "Error",
        description: "Please record or upload audio first",
        variant: "destructive"
      });
      return;
    }

    // Remove strict duration check, just warn if it's too long
    if (audioDuration > MAX_DURATION) {
      toast({
        title: "Warning",
        description: "Long recordings may take more time to analyze.",
      });
    }

    setIsAnalyzing(true);
    try {
      // Get the audio blob from the URL
      const response = await fetch(audioUrl);
      const audioBlob = await response.blob();

      // Analyze the audio
      const analysis = await analyzeMutation.mutateAsync(audioBlob);
      console.log("Analysis result:", analysis);

      // Create the report
      await createReportMutation.mutateAsync({
        title: `Speech Analysis ${new Date().toLocaleDateString()}`,
        audioUrl,
        duration: audioDuration,
        emotions: analysis.emotions,
        feedback: analysis.feedback
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to analyze speech. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Record Your Speech</h1>

      <div className="space-y-6">
        <AudioRecorder onRecordingComplete={handleRecordingComplete} />

        {audioUrl && (
          <div className="space-y-4">
            <audio src={audioUrl} controls className="w-full" />
            <Button 
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="w-full"
            >
              Analyze Speech
            </Button>
          </div>
        )}

        {isAnalyzing && (
          <div className="space-y-2">
            <Progress value={analyzeMutation.isPending ? 45 : 100} />
            <p className="text-center text-sm text-muted-foreground">
              {analyzeMutation.isPending ? "Analyzing speech..." : "Creating report..."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}