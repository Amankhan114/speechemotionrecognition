import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import EmotionChart from "@/components/emotion-chart";
import type { Report } from "@shared/schema";

export default function ReportDetail() {
  const { id } = useParams();
  
  const { data: report, isLoading } = useQuery<Report>({
    queryKey: [`/api/reports/${id}`]
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!report) {
    return <div>Report not found</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">{report.title}</h1>
        <p className="text-muted-foreground">
          {new Date(report.createdAt).toLocaleDateString()} • {Math.round(report.duration / 60)} minutes
        </p>
      </div>

      <Card>
        <CardContent className="p-6">
          <audio src={report.audioUrl} controls className="w-full" />
        </CardContent>
      </Card>

      <EmotionChart data={report.emotions} />

      <Card>
        <CardHeader>
          <CardTitle>Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-6 space-y-2">
            {report.feedback.map((feedback, index) => (
              <li key={index}>{feedback}</li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
