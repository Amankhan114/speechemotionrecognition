import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { Report } from "@shared/schema";

export default function Reports() {
  const { data: reports, isLoading } = useQuery<Report[]>({
    queryKey: ["/api/reports"]
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold mb-8">Your Reports</h1>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Your Reports</h1>
      
      {reports?.length === 0 ? (
        <Card className="p-6 text-center">
          <p className="text-muted-foreground">No reports yet. Start by recording a speech!</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {reports?.map((report) => (
            <Link key={report.id} href={`/reports/${report.id}`}>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardHeader>
                  <CardTitle>{report.title}</CardTitle>
                  <CardDescription>
                    {new Date(report.createdAt).toLocaleDateString()} • {Math.round(report.duration / 60)} minutes
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
