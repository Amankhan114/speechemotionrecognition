import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '@/components/ui/card';

interface EmotionData {
  time: number;
  confidence: number;
  nervousness: number;
  enthusiasm: number;
}

interface EmotionChartProps {
  data: EmotionData[];
}

export default function EmotionChart({ data }: EmotionChartProps) {
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Emotion Analysis</h3>
      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="time" 
              tickFormatter={formatTime}
              label={{ value: 'Time', position: 'bottom' }}
            />
            <YAxis label={{ value: 'Score', angle: -90, position: 'left' }} />
            <Tooltip 
              labelFormatter={formatTime}
              formatter={(value: number) => [Math.round(value), '']}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="confidence" 
              stroke="#4CAF50" 
              name="Confidence"
            />
            <Line 
              type="monotone" 
              dataKey="nervousness" 
              stroke="#F44336" 
              name="Nervousness"
            />
            <Line 
              type="monotone" 
              dataKey="enthusiasm" 
              stroke="#2196F3" 
              name="Enthusiasm"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
