import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Mic, 
  BarChart2, 
  Home, 
  LogOut,
  User
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function NavBar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const links = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/record", icon: Mic, label: "Record" },
    { href: "/reports", icon: BarChart2, label: "Reports" }
  ];

  if (!user) {
    return null;
  }

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <h1 className="text-xl font-bold">Speech Trainer</h1>
            <div className="flex gap-4">
              {links.map(({ href, icon: Icon, label }) => (
                <Link key={href} href={href}>
                  <a className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-md transition-colors",
                    location === href 
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  )}>
                    <Icon className="h-4 w-4" />
                    {label}
                  </a>
                </Link>
              ))}
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-destructive"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}