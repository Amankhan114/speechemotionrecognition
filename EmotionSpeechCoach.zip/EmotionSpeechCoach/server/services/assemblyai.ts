import { AssemblyAI } from 'assemblyai';
import FormData from "form-data";

const ASSEMBLY_API_KEY = process.env.ASSEMBLYAI_API_KEY;

if (!ASSEMBLY_API_KEY) {
  throw new Error("AssemblyAI API key is required");
}

const client = new AssemblyAI({
  apiKey: ASSEMBLY_API_KEY
});

export async function analyzeSpeech(audioBuffer: Buffer) {
  try {
    // First upload the audio file
    const formData = new FormData();
    formData.append("audio", audioBuffer);

    const uploadResponse = await fetch("https://api.assemblyai.com/v2/upload", {
      method: "POST",
      body: formData,
      headers: {
        "Authorization": ASSEMBLY_API_KEY
      }
    });

    if (!uploadResponse.ok) {
      throw new Error(`Upload failed: ${uploadResponse.statusText}`);
    }

    const { upload_url } = await uploadResponse.json();

    // Start transcription with sentiment analysis
    const transcript = await client.transcripts.create({
      audio_url: upload_url,
      sentiment_analysis: true,
      entity_detection: true,
      auto_chapters: true
    });

    // Wait for the analysis to complete
    const result = await client.transcripts.wait(transcript.id);

    // Process the results into our application's format
    const emotions = result.sentiment_analysis_results?.map((segment) => ({
      time: Math.floor(segment.start / 1000), // Convert from milliseconds to seconds
      confidence: segment.confidence * 100,
      nervousness: segment.sentiment === "NEGATIVE" ? 80 : 20,
      enthusiasm: segment.sentiment === "POSITIVE" ? 80 : 20
    })) || [];

    // Generate feedback based on the analysis
    const feedback = [];

    // Overall sentiment analysis
    const sentimentResults = result.sentiment_analysis_results || [];
    const positiveSentiments = sentimentResults.filter(
      (s) => s.sentiment === "POSITIVE"
    ).length;
    const totalSentiments = sentimentResults.length;
    const positiveRatio = totalSentiments > 0 ? positiveSentiments / totalSentiments : 0;

    if (positiveRatio < 0.3) {
      feedback.push("Your speech shows signs of low confidence or distress");
      feedback.push("Consider practicing relaxation techniques before speaking");
    } else if (positiveRatio > 0.7) {
      feedback.push("You maintained good enthusiasm throughout the speech");
    }

    // Chapter-based feedback
    if (result.chapters) {
      result.chapters.forEach((chapter) => {
        if (chapter.summary) {
          feedback.push(`Section "${chapter.headline}": ${chapter.summary}`);
        }
      });
    }

    // Add transcription-based feedback
    if (result.text) {
      feedback.push("Transcription feedback: " + result.text.substring(0, 200) + "...");
    }

    return {
      emotions,
      feedback: feedback.filter(Boolean) // Remove any empty feedback items
    };
  } catch (error) {
    console.error("Speech analysis error:", error);
    throw new Error("Failed to analyze speech");
  }
}