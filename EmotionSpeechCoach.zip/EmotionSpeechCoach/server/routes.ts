import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReportSchema } from "@shared/schema";
import { analyzeSpeech } from "./services/assemblyai";
import { Buffer } from "buffer";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes and middleware
  setupAuth(app);

  // Get all reports (protected)
  app.get("/api/reports", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const reports = await storage.getReports();
    res.json(reports);
  });

  // Get single report (protected)
  app.get("/api/reports/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const report = await storage.getReport(parseInt(req.params.id));
    if (!report) {
      res.status(404).json({ message: "Report not found" });
      return;
    }
    res.json(report);
  });

  // Create new report (protected)
  app.post("/api/reports", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      console.log("Received report data:", req.body);
      const data = insertReportSchema.parse({
        ...req.body,
        emotions: Array.isArray(req.body.emotions) ? req.body.emotions : [],
        feedback: Array.isArray(req.body.feedback) ? req.body.feedback : []
      });
      const report = await storage.createReport(data);
      res.status(201).json(report);
    } catch (error) {
      console.error('Report creation error:', error);
      res.status(400).json({ message: "Invalid report data" });
    }
  });

  // Real speech analysis (protected)
  app.post("/api/analyze", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      if (!req.body || !req.body.audio) {
        throw new Error("No audio data provided");
      }

      const audioBuffer = Buffer.from(req.body.audio, 'base64');
      const analysis = await analyzeSpeech(audioBuffer);

      res.json(analysis);
    } catch (error) {
      console.error('Analysis error:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to analyze speech" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}