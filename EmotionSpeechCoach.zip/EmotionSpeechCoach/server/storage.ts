import { reports, users, type Report, type InsertReport, type User, type InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Report methods
  getReports(): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;
  createReport(report: InsertReport): Promise<Report>;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private reports: Map<number, Report>;
  private users: Map<number, User>;
  private usersByUsername: Map<string, User>;
  private reportCurrentId: number;
  private userCurrentId: number;
  sessionStore: session.Store;

  constructor() {
    this.reports = new Map();
    this.users = new Map();
    this.usersByUsername = new Map();
    this.reportCurrentId = 1;
    this.userCurrentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // Report methods
  async getReports(): Promise<Report[]> {
    return Array.from(this.reports.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.reportCurrentId++;
    const report: Report = {
      id,
      ...insertReport,
      createdAt: new Date()
    };

    this.reports.set(id, {
      ...report,
      emotions: Array.isArray(report.emotions) ? report.emotions : [],
      feedback: Array.isArray(report.feedback) ? report.feedback : []
    });

    return this.reports.get(id)!;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return this.usersByUsername.get(username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = {
      id,
      ...insertUser
    };

    this.users.set(id, user);
    this.usersByUsername.set(user.username, user);

    return user;
  }
}

export const storage = new MemStorage();